'use strict';
const SHELL_CACHE = 'bonye.shell.2adf004df948f1b16e72';
const RESOURCES = new Set(["assets/AssetManifest.bin", "assets/AssetManifest.bin.json", "assets/AssetManifest.json", "assets/FontManifest.json", "assets/NOTICES", "assets/assets/fonts/CormorantGaramond.ttf", "assets/assets/fonts/NotoSansArabic.ttf", "assets/fonts/MaterialIcons-Regular.otf", "assets/shaders/ink_sparkle.frag", "canvaskit/canvaskit.js", "canvaskit/canvaskit.wasm", "canvaskit/chromium/canvaskit.js", "canvaskit/chromium/canvaskit.wasm", "canvaskit/skwasm.js", "canvaskit/skwasm.wasm", "canvaskit/skwasm_st.js", "canvaskit/skwasm_st.wasm", "favicon.png", "flutter.js", "flutter_bootstrap.js", "icons/Icon-192.png", "icons/Icon-512.png", "icons/Icon-maskable-512.png", "icons/apple-touch-icon.png", "index.html", "main.dart.js", "manifest.json", "source-revision.json", "version.json"]);
const PRECACHE = ["assets/AssetManifest.bin", "assets/AssetManifest.bin.json", "assets/AssetManifest.json", "assets/FontManifest.json", "assets/NOTICES", "assets/assets/fonts/CormorantGaramond.ttf", "assets/assets/fonts/NotoSansArabic.ttf", "assets/fonts/MaterialIcons-Regular.otf", "assets/shaders/ink_sparkle.frag", "canvaskit/canvaskit.js", "canvaskit/canvaskit.wasm", "canvaskit/chromium/canvaskit.js", "canvaskit/chromium/canvaskit.wasm", "favicon.png", "flutter.js", "flutter_bootstrap.js", "icons/Icon-192.png", "icons/Icon-512.png", "icons/Icon-maskable-512.png", "icons/apple-touch-icon.png", "index.html", "main.dart.js", "manifest.json", "source-revision.json", "version.json"];
const base = new URL('./', self.location.href);
self.addEventListener('install', event => {
  event.waitUntil(caches.open(SHELL_CACHE).then(cache =>
    cache.addAll(PRECACHE.map(path => new Request(new URL(path, base).href, {cache: 'reload'})))));
});
// A new worker activates after old tabs close, so an active purchase is not interrupted.
self.addEventListener('activate', event => {
  event.waitUntil(caches.keys().then(keys => Promise.all(keys
    .filter(key => key.startsWith('bonye.shell.') && key !== SHELL_CACHE)
    .map(key => caches.delete(key)))).then(() => self.clients.claim()));
});
self.addEventListener('fetch', event => {
  const request = event.request;
  const url = new URL(request.url);
  if (request.method !== 'GET' || url.origin !== base.origin ||
      !url.pathname.startsWith(base.pathname) || request.headers.has('Authorization')) return;
  let path = url.pathname.slice(base.pathname.length);
  if (path === '') path = 'index.html';
  // Exact shell allowlist: never cache API, checkout, customer data or arbitrary URLs.
  if (!RESOURCES.has(path) || url.search) return;
  const key = new URL(path, base).href;
  event.respondWith(caches.open(SHELL_CACHE).then(async cache => {
    const cached = await cache.match(key);
    if (cached) return cached;
    const response = await fetch(request);
    if (response.ok && response.type === 'basic') await cache.put(key, response.clone());
    return response;
  }));
});
